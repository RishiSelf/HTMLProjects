$(document).ready(function() {
	$(window).load(function() {
//        $(".landing-header").load("common_module/header.html");
        $(".landing-footer").load("common_module/footer.html");
		
    });
    
    
    
    
    if ($(window).width() > 1200) {
        var middleframeHeight = $('.middle-content-row').height();
        var leftlisitingHeight = $('.middle-content-row .left-side-col').height();
        if(middleframeHeight >= leftlisitingHeight) {
            $('.middle-content-row .left-side-col').css('minHeight', middleframeHeight);
        }
    }else {
        
    }// Left Listing Min Height Functionality End///
    
   
    $('.side-menu-list').click(function(){
        if($('.left-side-col').is(':hidden')){
//            alert("Hide hai");
            $('.left-side-col').show(500);
            $('.side-menu-list').addClass('activeMenu');
        }
        else {
//            alert("visible hai");
            $('.left-side-col').hide();
            $('.side-menu-list').removeClass('activeMenu');
        }
    });
   
});//document Ready End//

$(window).resize(function(){
    var screenHeight = window.innerHeight;
    //console.log(screenHeight);
	//$('.content-area').css('minHeight', screenHeight - 80);
});//Window Resize End//



$(document).on('click', '.side-menu-list', function(){
    if($('.left-side-col').is(':hidden')){
//            alert("Hide hai");
        $('.left-side-col').show(500);
        $('.side-menu-list').addClass('activeMenu');
    }
    else {
//            alert("visible hai");
        $('.left-side-col').hide();
        $('.side-menu-list').removeClass('activeMenu');
    }
});

